<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" author="Alfonso Marquez" content="width=device-width, initial-scale=1.0">

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" type="text/css"/>
    

     <!-- Fonts -->
     <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;800&display=swap" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
     <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.bundle.min.js"></script>

    <title>Portfolio | Alfonso</title>
</head>
<body>

    <?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="app">      
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src=" <?php echo e(asset('/js/app.js')); ?> "></script>
</body>
</html><?php /**PATH C:\Users\Alfonso\Documents\portfolio-1\resources\views/layouts/app.blade.php ENDPATH**/ ?>