<div class="container-fluid profile">
    <div class="row">
        <div class="col-2 offset-3 profile__image">
            <img class="rounded-circle" src="/image/alfonso-1.jpg">
        </div>
        <div class="col-5 profile__details">
            <div>
                <h2>Jose Alfonso Marquez</h2>
                <p>Bachelor of Science in Computer Engineering<br>Software Engineer<br> 
                    <span style="font-style:italic"> Proactive | Teamplayer | Always Curious </span>
                    
                </p>
            </div>    
        </div>
    </div>
    <div class="line-div row">
        <div class="col-12">
            
        </div>
    </div>
    <div class=" tabnav row">
        <div class="col-4 offset-4">
            <ul class="nav nav-fill">
                
                <li class="nav-item">
                    <a data-toggle="tab" class="nav-link active" href="#about">ABOUT</a>
                </li>
                <li class="nav-item">
                    <a data-toggle="tab" class="nav-link" href="#projects">PROJECTS</a>
                </li>
                <li class="nav-item">
                    <a data-toggle="tab" class="nav-link" href="#interests">INTERESTS</a>
                </li>
            </ul>
        </div>
    </div>
    
</div>
<?php /**PATH C:\Users\Alfonso\Documents\portfolio-1\resources\views/inc/header.blade.php ENDPATH**/ ?>