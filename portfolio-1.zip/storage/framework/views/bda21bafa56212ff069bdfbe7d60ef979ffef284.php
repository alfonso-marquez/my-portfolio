<div class="container">
    <div class="interests row mt-3">
        <div class="col-12 pt-3">
            <h3>Coming Soon!</h3>
            <h3>Interests</h3>
            <h3>Music</h3>
            <h3>Sports</h3>
        </div>
    </div>
</div><?php /**PATH C:\Users\Alfonso\Documents\portfolio-1\resources\views/inc/interests.blade.php ENDPATH**/ ?>