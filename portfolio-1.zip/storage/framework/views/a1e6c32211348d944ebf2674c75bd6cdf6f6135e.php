<div class="container">
    <div class="row mt-3 projects">
        <?php for($i = 1; $i < 10; $i++): ?>
            <div class="col-4 pb-4">
                <a href="/<?php echo e($i); ?>">
                    <img class="w-100" src="/image/youliveit.jpg" alt="">
               </a>   
            </div> 
        <?php endfor; ?>
    </div>
</div><?php /**PATH C:\Users\Alfonso\Documents\portfolio-1\resources\views/inc/projects.blade.php ENDPATH**/ ?>