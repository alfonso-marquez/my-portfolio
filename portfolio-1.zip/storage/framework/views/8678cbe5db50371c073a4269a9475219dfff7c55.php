

<?php $__env->startSection('content'); ?>
<div class="container">
     <div class="row pt-5 timeline">
         <?php for($i = 1; $i < 13; $i++): ?>
             <div class="col-4 pb-4">
                 <a href="/<?php echo e($i); ?>">
                     <img class="w-100" src="/image/youliveit.jpg" alt="">
                 </a>   
             </div> 
         <?php endfor; ?>
 </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alfonso\Documents\portfolio-1\resources\views/about.blade.php ENDPATH**/ ?>