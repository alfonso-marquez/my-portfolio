

<?php $__env->startSection('content'); ?>
    <div class="main container">
        <div class="tab-content">
            
            <div id="about" class="tab-pane fade show active">
                <?php echo $__env->make('inc.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div id="projects" class="tab-pane fade">
                <?php echo $__env->make('inc.projects', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div id="interests" class="tab-pane fade">
                <?php echo $__env->make('inc.interests', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alfonso\Documents\portfolio-1\resources\views/main.blade.php ENDPATH**/ ?>