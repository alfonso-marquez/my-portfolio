<div class="container">
    <div class="row mt-3 projects">
        @for ($i = 1; $i < 10; $i++)
            <div class="col-4 pb-4">
                <a href="/{{ $i }}">
                    <img class="w-100" src="/image/youliveit.jpg" alt="">
               </a>   
            </div> 
        @endfor
    </div>
</div>